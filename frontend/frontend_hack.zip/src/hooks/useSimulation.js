import { useState, useEffect, useRef, useCallback } from 'react';

const WS_URL  = 'ws://localhost:8000/ws';
const API_URL = 'http://localhost:8000/api';

export function useSimulation() {
  const [state, setState] = useState({
    robots: [], lanes: [], nodes: [], heatmap: {}, metrics: {},
    running: false, tick: 0, connected: false,
    speed_multiplier: 1.0, near_miss_ids: [],
    signal_phase: 0, signal_progress: 0,
    task_summary: { queued: 0, active: 0, completed: 0, tasks_list: [], active_tasks: [], recent_completed: [] },
    metrics_history: [],
    goal_reached: [],
  });

  const wsRef     = useRef(null);
  const reconnRef = useRef(null);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;
      ws.onopen = () => setState(p => ({ ...p, connected: true }));
      ws.onmessage = e => {
        try {
          const d = JSON.parse(e.data);
          if (d.type === 'state_update' || d.type === 'init') {
            setState(p => ({
              ...p,
              robots:           d.robots           ?? p.robots,
              lanes:            d.lanes            ?? p.lanes,
              nodes:            d.nodes            ?? p.nodes,
              heatmap:          d.heatmap          ?? p.heatmap,
              metrics:          d.metrics          ?? p.metrics,
              running:          d.running          ?? p.running,
              tick:             d.tick             ?? p.tick,
              speed_multiplier: d.speed_multiplier ?? p.speed_multiplier,
              near_miss_ids:    d.near_miss_ids    ?? p.near_miss_ids,
              signal_phase:     d.signal_phase     ?? p.signal_phase,
              signal_progress:  d.signal_progress  ?? p.signal_progress,
              task_summary:     d.task_summary     ?? p.task_summary,
              metrics_history:  d.metrics_history  ?? p.metrics_history,
              goal_reached:     d.goal_reached     ?? [],
            }));
          }
        } catch (_) {}
      };
      ws.onclose = () => { setState(p => ({ ...p, connected: false })); reconnRef.current = setTimeout(connect, 2500); };
      ws.onerror = () => ws.close();
    } catch (_) { reconnRef.current = setTimeout(connect, 3000); }
  }, []);

  useEffect(() => { connect(); return () => { clearTimeout(reconnRef.current); wsRef.current?.close(); }; }, [connect]);

  const api = useCallback(async (endpoint, method = 'GET', body = null) => {
    try {
      const res = await fetch(`${API_URL}${endpoint}`, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined,
      });
      return await res.json();
    } catch (e) { console.error('API error:', e); return null; }
  }, []);

  return {
    state,
    startSim:        ()           => api('/simulation/start', 'POST'),
    stopSim:         ()           => api('/simulation/stop',  'POST'),
    resetSim:        (count)      => api('/simulation/reset', 'POST', { robot_count: count }),
    setSpeed:        (mult)       => api('/simulation/speed', 'POST', { multiplier: mult }),
    emergencyStop:   (id)         => api(`/robots/${id}/emergency-stop`, 'POST'),
    resumeRobot:     (id)         => api(`/robots/${id}/resume`,         'POST'),
    setRobotGoal:    (id, nodeId) => api(`/robots/${id}/goal`,           'POST', { goal_node_id: nodeId }),
    blockLane:       (laneId)     => api(`/lanes/${laneId}/block`,       'POST'),
    unblockAll:      ()           => api('/lanes/unblock-all',           'POST'),
    addTask:         (body)       => api('/tasks/add',                   'POST', body),
  };
}